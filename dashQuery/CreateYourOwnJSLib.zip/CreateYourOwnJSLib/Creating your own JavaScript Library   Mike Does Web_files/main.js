jQuery(function($){

	$('.menu__expand').click(function(){
		$('.menu__list').toggleClass('menu__list--collapse');
	});

});


// //Set up global site object and children
// if(typeof(mj) != 'object'){
// 	mj = {};
// }
// if(typeof(mj.vars) != 'object'){
// 	mj.vars = {};
// }


// //Variables used in mj.headerAnimation cached here for performace
// mj.vars = {};
// mj.vars.subHeight = 0,
// mj.vars.tHeight = 0,
// mj.vars.initialPadding = 75,
// mj.vars.threshhold = 150,
// $subTitle = document.getElementById("subTitle"),
// $title = document.getElementById('title'),
// $header = document.getElementById("header"),
// $link = document.getElementById('homeLink');

// //Header animation function
// mj.headerAnimation = function (){
// 	//Variables we can't cache
// 	var scroll = window.scrollY,
// 		sbtOpacity = 1 - (scroll / (mj.vars.threshhold/2)),
// 		tOpacity = 1 - (scroll/mj.vars.threshhold);
// 		padding = 20 - (scroll / 20),
// 		newSubHeight = mj.vars.subHeight - ((scroll / mj.vars.threshhold/2) * mj.subHeight),
// 		newtHeight = mj.vars.tHeight - ((scroll / mj.vars.threshhold/2) * mj.vars.tHeight);

// 	//Set opacities
// 	$header.style.opacity = tOpacity;
// 	$subTitle.style.opacity = sbtOpacity;

// 	//Set heights
// 	$subTitle.style.height = newSubHeight + "px";
// 	$title.style.height = newtHeight + "px";

// 	//Set paddings
// 	$header.style.paddingTop = padding + "px";
// 	$header.style.paddingBottom = padding + "px";

// 	//Swap link text and background	
// 	$link.innerText = scroll > mj.vars.threshhold - 10 ? "Michael Jasper" : "Home";
// 	$link.textContent = scroll > mj.vars.threshhold - 10 ? "Michael Jasper" : "Home";
// 	$link.style.background = scroll > mj.vars.threshhold - 10 ? "#2f3440" : "";
// 	$link.style.paddingLeft = scroll > mj.vars.threshhold - 10 ? "0" : "15px"; 
// }


// mj.pageLoad = function(){
// 	//Set Title initial height
// 	mj.vars.tHeight = window.getComputedStyle($title,null).getPropertyValue("height").replace("px","");

// 	//Set Subtitle initial height
// 	mj.vars.subHeight = window.getComputedStyle($subTitle,null).getPropertyValue("height").replace("px","");

// 	//Bootstrap the load events

// 	//Add scroll listener for animation
// 	window.addEventListener('scroll', mj.headerAnimation, false);


// }


// window.addEventListener('load', mj.pageLoad, false);